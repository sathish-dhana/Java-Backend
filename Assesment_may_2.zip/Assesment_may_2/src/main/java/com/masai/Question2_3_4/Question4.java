package com.masai.Question2_3_4;

public class Question4 {
	
	
	//Client Server Architecture//
	
	/*
	 * it is a 2-tier architecture 
	 * here presentation is viewd on client side & logic and processing done in the server side.
	 * the data is stored in server side.
	 * 
	 */
	
	//Caching//
	
	/*
	 * Caching is a temprovary memory used to store and access data.  
	 * it will consume more time to get data from servers, so we are using caching to store 
	 * more frequently accesed data to improve speed and performance.
	 * 
	 */
	
	//Web Sockets//
	/*
	 * Web sockets are bi-directional 
	 * it allows both parties to push message at same time (example : muliplayer game)
	 * 
	 * 
	 */
	
	//public and private keys used in encryption and decryption//
	/*
	 * public key is used to encrypt data
	 * private key us used to decrypt data.
	 * 
	 * this provides security in olden days, but this too has some drawbacks because
	 * still people can get data because we need to send private key to decrypt data.
	 * 
	 * so now, both parties have pair of keys public and private(ex : like gmail login)
	 * 
	 */
}
