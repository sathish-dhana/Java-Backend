package com.masai.Question1.Config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan(basePackages = "com.masai.Question1")
public class Appconfig {

}
